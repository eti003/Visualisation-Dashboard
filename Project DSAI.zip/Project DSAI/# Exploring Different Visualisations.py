# Exploring Different Visualisations
import streamlit as st
import numpy as np
import pandas as pd
import seaborn as sns
import altair as alt
import plotly.express as px

# Step 1: Importing the dataset
df = pd.read_csv("C:\\Users\\ETI\\Downloads\\Country_clean (1).csv")
l = ["Population","Area"]
# Noramlisation
df["Population"]=(df["Population"]-df["Population"].mean())/df["Population"].std()
df["Area"]=(df["Area"]-df["Area"].mean())/df["Area"].std()
# Make a scatter plot
import matplotlib.pyplot as plt

fig = plt.figure()
ax = fig.add_subplot(1,1,1)

ax.scatter(
        df["Population"],
        df["Area"],
    )

ax.set_xlabel("Population")
ax.set_ylabel("Area")

st.write(fig)

fig_1 = plt.figure(figsize = (10, 5))
ax.bar(df["Population"],df["Area"])
st.write(fig_1)
# Line Chart
a = pd.DataFrame({"Name": df["Country Name"],"Population":df["Population"]})

st.line_chart(df["Population"])
# Area Chart
st.area_chart(df["Population"])
# Histogram
arr = df["Population"]
fig, ax = plt.subplots()
ax.hist(arr)

st.pyplot(fig)
# Checkbox
filter = st.selectbox("Select the Category",df.columns.values)
option = st.selectbox(
     'What type of graph?',
     ('Area Chart', 'Line Chart'))

if option=="Area Chart":
    st.area_chart(df[filter])
else:
    st.line_chart(df[filter])
st.write(df.head())
df = df.fillna(value=0)



