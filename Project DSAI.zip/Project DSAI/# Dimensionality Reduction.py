# Dimensionality Reduction
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt
import streamlit as st

data = pd.read_csv("C:\\Users\\ETI\\Downloads\\Country_clean (1).csv")

df = data.fillna(value=0)
target = []
for i in range(197):
    target.append(i)
from sklearn.decomposition import PCA # Principal Component Analysis module
from sklearn.manifold import TSNE # TSNE module

l = ['Area',"Population","GDP - per capita (PPP)","Labor force"]
X = df[l].values

pca = PCA(n_components=2)
pca_2d = pca.fit_transform(X)

# Invoke the TSNE method
tsne = TSNE(n_components=2, verbose=1, perplexity=40, n_iter=2000)
tsne_results = tsne.fit_transform(X)

plt.figure(figsize = (16,11))
plt.subplot(121)
plt.scatter(pca_2d[:,0],pca_2d[:,1], c = target, 
            cmap = "coolwarm", edgecolor = "None", alpha=0.35)
plt.colorbar()
plt.title('PCA Scatter Plot')
plt.subplot(122)
a = plt.scatter(tsne_results[:,0],tsne_results[:,1],  c = target, 
            cmap = "coolwarm", edgecolor = "None", alpha=0.35)
plt.colorbar()
plt.title('TSNE Scatter Plot')
plt.show()
st.write(a)