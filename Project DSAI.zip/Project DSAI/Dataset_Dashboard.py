from audioop import avg
import time # to simulate real time data, a time loop
import numpy as np # np.mean, np.random
import pandas as pd # to read csv file
import plotly.express as px # interactive charts
import streamlit as st # data web app development

st.set_page_config(
    page_title="Real-Time Data Science Dashboard",
    page_icon="✅",
    layout="wide",
)

dataset_url = "C:\\Users\\ETI\\Downloads\\Country_clean (1).csv"
# read csv from a URL
@st.experimental_memo
def get_data() -> pd.DataFrame:
    return pd.read_csv(dataset_url)

df = get_data()

st.title("Real Time/Live Data Analysis")
# Tope level filter
gov_filter = st.selectbox("Select the Government",pd.unique(df["Government Type"]))
# Data Frame Filter
df = df[df["Government Type"]==gov_filter]
# Create three columns
kpi1, kpi2 = st.columns(2)
kpi1.metric(
    label = "Area",
    value = np.mean(df["Area"]),
)
kpi2.metric(
    label = "Population",
    value = np.mean(df["Population"]),
)
fig_col1,fig_col2 = st.columns(2)

with fig_col1:
    st.markdown("###First Chart")
    fig = px.density_heatmap(
        data_frame=df, y="Population", x="Area"
    )
    st.write(fig)
   
with fig_col2:
    st.markdown("### Second Chart")
    fig2 = px.histogram(data_frame=df, x="Area")
    st.write(fig2)
st.markdown("### Detailed Data View")
st.dataframe(df)

