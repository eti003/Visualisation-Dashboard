# Visualization using Dash
import pandas as pd
from dash import Dash, html, dcc
import plotly.express as px

app = Dash(__name__)

df = pd.read_csv("C:\\Users\\ETI\\Downloads\\Country_clean (1).csv")
fig = px.bar(df,x="Area",y="Population",color="Government Type",barmode="group")

app.layout = html.Div(children=[
    html.H1(children='Hello Dash'),

    html.Div(children='''
        Dash: A web application framework for your data.
    '''),

    dcc.Graph(
        id='example-graph',
        figure=fig
    )
])

if __name__ == '__main__':
    app.run_server(debug=True)