# Tsne
import numpy as np # linear algebra
import seaborn as sns
import matplotlib
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
import plotly.express as px
from dash import Dash, dcc, html, Input, Output

data = pd.read_csv("C:\\Users\\ETI\\Downloads\\Country_clean (1).csv")

df = data.fillna(value=0)

features = ["Population","GDP - per capita (PPP)","Labor force"]


from sklearn.manifold import TSNE
import plotly.express as px


feature = df.loc[:, features]

tsne = TSNE(n_components=2, random_state=0)
projections = tsne.fit_transform(feature)

fig = px.scatter(
    projections, x=0, y=1,
    color=df["Country Name"], labels={'color': 'Country Name'}
)
fig.show()




app = Dash(__name__)

app.layout = html.Div([
    dcc.Graph(id='graph-with-slider'),
    dcc.Slider(
        df['Area'].min(),
        df['Area'].max(),
        step=None,
        value=df['Area'].min(),
        marks={str(Area): str(Area) for Area in df['Area'].unique()},
        id='area-slider'
    )
])


@app.callback(
    Output('graph-with-slider', 'figure'),
    Input('year-slider', 'value'))
def uf(area):
        Area = df[df.Area==area]
        features.append(Area)
        feature = df.loc[:, features]

        tsne = TSNE(n_components=2, random_state=0)
        projections = tsne.fit_transform(feature)

        fig = px.scatter(
            projections, x=0, y=1,
            color=df["Country Name"], labels={'color': 'Country Name'}
            )
        return fig
if __name__ == '__main__':
    app.run_server(debug=False)


