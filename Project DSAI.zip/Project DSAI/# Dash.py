# Dash
from dash import Dash, html, dcc
import plotly.express as px
import pandas as pd

app = Dash(__name__)

dff = pd.read_csv("C:\\Users\\ETI\\Downloads\\Country_clean (1).csv")
df = dff.fillna(value = 0)

def normal(c):
    return (c-c.mean())/c.std()
df["Area"]=normal(df["Area"])

df["Labor force"]=normal(df["Labor force"])


fig_1 = px.scatter(df,x = "Area", y = "Labor force", size = "Population", color="Government Type",hover_name="Country Name", log_x=True, size_max=60)

app.layout = html.Div(children=[
    html.H1(children='Hello Dash'),

    html.Div(children='''
        Dash: A web application framework for your data.
    '''),

    dcc.Graph(
        id='example-graph',
        figure=fig_1
    )
])

if __name__ == '__main__':
    app.run_server(debug=False)


